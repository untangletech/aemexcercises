package com.roche.cmms.core.constants;

public class CMMSConstants {

    public static String LOGIN_PATH = "/system/sling/login?resource=";

}
