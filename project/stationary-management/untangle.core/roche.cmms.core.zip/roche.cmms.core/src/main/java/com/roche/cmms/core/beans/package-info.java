/**
 * 
 */
/**
 * @author adisagga
 *
 */
package com.roche.cmms.core.beans;
