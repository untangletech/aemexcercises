package com.roche.cmms.core.beans;

public class CountryBean {
    private String countryDisplayName;
    
    private String countrySpaPath;
    
    private String countryCode;
    
    public String getCountryDisplayName() {
        return countryDisplayName;
    }
    
    public void setCountryDisplayName(String countryDisplayName) {
        this.countryDisplayName = countryDisplayName;
    }
    
    public String getCountrySpaPath() {
        return countrySpaPath;
    }
    
    public void setCountrySpaPath(String countrySpaPath) {
        this.countrySpaPath = countrySpaPath;
    }
    
    public String getCountryCode() {
        return countryCode;
    }
    
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
    
}
