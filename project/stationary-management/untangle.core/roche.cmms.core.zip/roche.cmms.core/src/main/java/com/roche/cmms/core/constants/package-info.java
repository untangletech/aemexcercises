/**
 * 
 */
/**
 * @author adisagga
 *
 */
package com.roche.cmms.core.constants;
