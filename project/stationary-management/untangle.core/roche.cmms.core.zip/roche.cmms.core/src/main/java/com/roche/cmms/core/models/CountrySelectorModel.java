package com.roche.cmms.core.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import com.google.gson.Gson;
import com.roche.cmms.core.beans.CountryBean;
import com.roche.cmms.core.constants.CMMSConstants;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CountrySelectorModel {
    
    @ValueMapValue
    private String[] countryList;

    private List<CountryBean> countryBeanList;
    
    @PostConstruct
    protected void postConstruct() {
        final List<CountryBean> nonSortedCountry = new ArrayList<CountryBean>();
        if (countryList != null) {
            for (final String country : countryList) {
                nonSortedCountry.add(getCountryBean(country));

            }
        }

        Collections.sort(nonSortedCountry, new Comparator<CountryBean>() {

            @Override
            public int compare(CountryBean country1, CountryBean country2) {
                
                return country1.getCountryDisplayName().compareToIgnoreCase(country2.getCountryDisplayName());
            }
        });
        
        setCountryBeanList(nonSortedCountry);
        updateLoginPath();
    }
    
    private void updateLoginPath() {
        if (countryBeanList != null && countryBeanList.size() > 0) {
            for (final CountryBean countryBean : countryBeanList) {
                countryBean.setCountrySpaPath(CMMSConstants.LOGIN_PATH + countryBean.getCountrySpaPath());
            }
        }
    }
    
    private CountryBean getCountryBean(final String countryJson) {
        final Gson gson = new Gson();
        return gson.fromJson(countryJson, CountryBean.class);
    }
    
    public String[] getCountryList() {
        return countryList;
    }

    public List<CountryBean> getCountryBeanList() {
        return countryBeanList;
    }
    
    public void setCountryBeanList(List<CountryBean> countryBeanList) {
        this.countryBeanList = countryBeanList;
    }
    
}
